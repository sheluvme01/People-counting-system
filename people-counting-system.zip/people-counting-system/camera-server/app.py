"""
CAMERA SERVER
=============
Nhận các khung hình từ camera (hoặc file/URL) và gửi đến Kafka topic.
Đây là điểm đầu vào của pipeline Big Data.
"""

import os
import uuid
import base64
import json
import time
import logging
import threading
from datetime import datetime
from flask import Flask, request, jsonify
from kafka import KafkaProducer
from kafka.errors import KafkaError
import cv2
import numpy as np

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [CAMERA-SERVER] %(levelname)s %(message)s'
)
logger = logging.getLogger(__name__)

# ── Flask App ─────────────────────────────────────────────────────────────────
app = Flask(__name__)

# ── Config ───────────────────────────────────────────────────────────────────
KAFKA_BOOTSTRAP_SERVERS = os.environ.get('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
KAFKA_TOPIC_FRAMES      = os.environ.get('KAFKA_TOPIC_FRAMES', 'camera-frames')
MAX_IMAGE_SIZE          = 10 * 1024 * 1024   # 10 MB


# ── Kafka Producer ────────────────────────────────────────────────────────────
def create_producer():
    retries = 10
    for attempt in range(retries):
        try:
            producer = KafkaProducer(
                bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
                value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                max_request_size=MAX_IMAGE_SIZE,
                compression_type='gzip',
                acks='all',
                retries=3,
            )
            logger.info("✅ Kafka Producer connected: %s", KAFKA_BOOTSTRAP_SERVERS)
            return producer
        except Exception as exc:
            logger.warning("Kafka not ready (%d/%d): %s", attempt + 1, retries, exc)
            time.sleep(5)
    raise RuntimeError("Cannot connect to Kafka after %d attempts" % retries)


producer = None

def get_producer():
    global producer
    if producer is None:
        producer = create_producer()
    return producer


# ── Stats ─────────────────────────────────────────────────────────────────────
stats = {
    'frames_sent'  : 0,
    'frames_failed': 0,
    'started_at'   : datetime.utcnow().isoformat(),
}


# ── Helpers ───────────────────────────────────────────────────────────────────
def encode_image(img_bytes: bytes) -> str:
    """Convert raw bytes → base64 string."""
    return base64.b64encode(img_bytes).decode('utf-8')


def resize_if_needed(img_bytes: bytes, max_wh: int = 640) -> bytes:
    """Resize image so the longer side ≤ max_wh (keeps aspect ratio)."""
    arr  = np.frombuffer(img_bytes, np.uint8)
    img  = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return img_bytes
    h, w = img.shape[:2]
    if max(h, w) <= max_wh:
        return img_bytes
    scale    = max_wh / max(h, w)
    new_size = (int(w * scale), int(h * scale))
    resized  = cv2.resize(img, new_size, interpolation=cv2.INTER_AREA)
    _, buf   = cv2.imencode('.jpg', resized, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return buf.tobytes()


def send_frame_to_kafka(frame_bytes: bytes, camera_id: str,
                        frame_id: str = None) -> dict:
    """Package frame and publish to Kafka."""
    frame_id   = frame_id or str(uuid.uuid4())
    timestamp  = datetime.utcnow().isoformat()

    # Resize to reduce Kafka message size
    frame_bytes = resize_if_needed(frame_bytes, max_wh=640)

    message = {
        'frame_id'  : frame_id,
        'camera_id' : camera_id,
        'timestamp' : timestamp,
        'image_b64' : encode_image(frame_bytes),
        'source'    : 'camera-server',
    }

    future = get_producer().send(KAFKA_TOPIC_FRAMES, value=message)
    future.get(timeout=30)   # blocking confirm

    stats['frames_sent'] += 1
    logger.info("📤 Frame sent → Kafka | frame_id=%s camera=%s", frame_id, camera_id)
    return {'frame_id': frame_id, 'timestamp': timestamp}


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'service': 'camera-server', **stats})


@app.route('/send-frame', methods=['POST'])
def send_frame():
    """Upload a single JPEG/PNG frame for processing."""
    camera_id = request.form.get('camera_id', 'CAM-001')

    if 'frame' not in request.files:
        return jsonify({'error': 'No frame file provided (field: frame)'}), 400

    file  = request.files['frame']
    data  = file.read()
    if not data:
        return jsonify({'error': 'Empty file'}), 400

    try:
        result = send_frame_to_kafka(data, camera_id)
        return jsonify({'success': True, 'camera_id': camera_id, **result})
    except KafkaError as exc:
        stats['frames_failed'] += 1
        logger.error("Kafka error: %s", exc)
        return jsonify({'error': str(exc)}), 500


@app.route('/simulate-camera', methods=['POST'])
def simulate_camera():
    """
    Simulate a camera stream by sending multiple synthetic frames.
    Body JSON: { "camera_id": "CAM-001", "num_frames": 5 }
    """
    body       = request.get_json(silent=True) or {}
    camera_id  = body.get('camera_id', 'CAM-SIM-001')
    num_frames = min(int(body.get('num_frames', 5)), 20)

    sent = []

    def run():
        for i in range(num_frames):
            # Generate a synthetic frame with random "people" rectangles
            img = np.zeros((480, 640, 3), dtype=np.uint8)
            img[:] = (30, 30, 30)   # dark background

            n_people = np.random.randint(1, 8)
            for _ in range(n_people):
                x1 = np.random.randint(0, 540)
                y1 = np.random.randint(0, 380)
                x2 = x1 + np.random.randint(60, 100)
                y2 = y1 + np.random.randint(100, 140)
                color = tuple(int(c) for c in np.random.randint(100, 255, 3).tolist())
                cv2.rectangle(img, (x1, y1), (x2, y2), color, -1)

            cv2.putText(img, f"Frame {i+1} | {camera_id}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

            _, buf   = cv2.imencode('.jpg', img)
            result   = send_frame_to_kafka(buf.tobytes(), camera_id)
            sent.append(result)
            time.sleep(0.5)

        logger.info("🎬 Simulation done: %d frames for %s", num_frames, camera_id)

    t = threading.Thread(target=run, daemon=True)
    t.start()

    return jsonify({
        'success'    : True,
        'camera_id'  : camera_id,
        'num_frames' : num_frames,
        'message'    : f'Sending {num_frames} frames in background',
        'kafka_topic': KAFKA_TOPIC_FRAMES,
    })


@app.route('/stats', methods=['GET'])
def get_stats():
    return jsonify({'service': 'camera-server', **stats})


# ── Entry ─────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=False)
