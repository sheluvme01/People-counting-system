# Kiến trúc Chi Tiết — People Counting System

## Luồng dữ liệu (Data Flow)

```
Camera / Client
      │
      │  POST /send-frame  (multipart/form-data)
      │  POST /simulate-camera  (JSON)
      ▼
┌─────────────────────────────────────────────────────┐
│             CAMERA SERVER  :5001                    │
│                                                     │
│  1. Nhận file ảnh từ HTTP request                   │
│  2. Resize → tối đa 640px (giảm băng thông Kafka)   │
│  3. Encode → Base64 string                          │
│  4. Đóng gói JSON message:                          │
│     { frame_id, camera_id, timestamp, image_b64 }   │
│  5. Publish → Kafka topic "camera-frames" (GZIP)    │
└─────────────────────────────────────────────────────┘
                          │
                          │  Kafka: camera-frames
                          │  (Persistent, replayable)
                          ▼
┌─────────────────────────────────────────────────────┐
│           PROCESSING SERVER  :5002                  │
│                                                     │
│  1. Subscribe Kafka topic "camera-frames"           │
│  2. Decode Base64 → OpenCV image                    │
│  3. HOG detectMultiScale() → raw detections         │
│  4. Non-Maximum Suppression → loại bỏ duplicate     │
│  5. Vẽ bounding boxes lên ảnh (annotated frame)     │
│  6. Tạo result message:                             │
│     { frame_id, camera_id, people_count,            │
│       bounding_boxes[], annotated_frame,            │
│       processing_ms, detector }                     │
│  7. Publish → Kafka topic "detection-results"       │
└─────────────────────────────────────────────────────┘
                          │
                          │  Kafka: detection-results
                          │  (Persistent, replayable)
                          ▼
┌─────────────────────────────────────────────────────┐
│            STORAGE SERVER  :5003                    │
│                                                     │
│  1. Subscribe Kafka topic "detection-results"       │
│  2. Insert document → MongoDB "detection_results"   │
│  3. Upsert per-minute bucket → "minute_stats"       │
│  4. Cung cấp REST API:                              │
│     GET /results      — Danh sách kết quả          │
│     GET /results/:id  — Chi tiết một frame          │
│     GET /summary      — Tổng hợp theo camera        │
│     GET /timeline     — Xu hướng theo phút          │
│     GET /cameras      — Danh sách cameras           │
└─────────────────────────────────────────────────────┘
                          │
                          ▼
                    ┌──────────┐
                    │ MongoDB  │
                    │ :27017   │
                    └──────────┘
```

### 1. Kafka — Nền tảng Streaming
- **Distributed commit log**: Mọi frame đều được lưu trên Kafka với TTL cấu hình được
- **Consumer Groups**: Nhiều processing server cùng consume một topic song song
- **Replayability**: Có thể reprocess toàn bộ lịch sử nếu cần
- **Decoupling**: Camera server và Processing server hoàn toàn độc lập

### 2. MongoDB — Lưu trữ phân tán
- **Schema-less**: Bounding boxes có số lượng thay đổi → document store phù hợp hơn SQL
- **Indexing**: Index trên `timestamp`, `camera_id`, `frame_id`
- **Aggregation Pipeline**: Tính tổng, trung bình, max người theo camera

### 3. Horizontal Scalability
```bash
# Scale processing lên 4 instances
docker compose up --scale processing-server=4 -d
# Kafka tự phân phối partitions cho 4 consumer
```

### 4. Fault Tolerance
- **Kafka**: Message được replicate (cấu hình production)
- **Consumer group offset**: Nếu processing server crash, consumer khác tiếp tục từ offset cuối
- **MongoDB**: Retry logic khi insert thất bại

## Detector: HOG + SVM

HOG (Histogram of Oriented Gradients) là descriptor đặc trưng được dùng kết hợp với SVM (Support Vector Machine) — đây là mô hình nhận diện người tiêu chuẩn trong OpenCV.

```
Frame Input (640×480)
        │
        ▼
  HOG Feature Extraction
  (Sliding window 64×128, stride 8×8)
        │
        ▼
  SVM Classification
  (Default people detector: trained on INRIA dataset)
        │
        ▼
  Raw Detections
  (Nhiều overlapping boxes)
        │
        ▼
  Non-Maximum Suppression (overlap > 0.45)
        │
        ▼
  Final Bounding Boxes
  [{ x, y, w, h, confidence, label: "person" }]
```
