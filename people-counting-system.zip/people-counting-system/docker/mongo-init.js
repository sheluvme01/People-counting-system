db = db.getSiblingDB('people_counting');

db.createCollection('detection_results');
db.createCollection('camera_sessions');
db.createCollection('frame_stats');

db.detection_results.createIndex({ timestamp: -1 });
db.detection_results.createIndex({ camera_id: 1 });
db.detection_results.createIndex({ frame_id: 1 }, { unique: true });

db.camera_sessions.createIndex({ camera_id: 1 });
db.camera_sessions.createIndex({ started_at: -1 });

print('MongoDB initialized successfully for people_counting database');
