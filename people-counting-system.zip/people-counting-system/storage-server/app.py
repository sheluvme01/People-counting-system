"""
STORAGE SERVER
==============
Tiêu thụ kết quả nhận diện từ Kafka, lưu vào MongoDB, và
cung cấp REST API để truy vấn thống kê.
"""

import os
import json
import time
import logging
import threading
from datetime import datetime
from flask import Flask, request, jsonify
from kafka import KafkaConsumer
from pymongo import MongoClient, DESCENDING
from pymongo.errors import PyMongoError

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [STORAGE-SERVER] %(levelname)s %(message)s'
)
logger = logging.getLogger(__name__)

# ── Flask ─────────────────────────────────────────────────────────────────────
app = Flask(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
KAFKA_BOOTSTRAP_SERVERS = os.environ.get('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
KAFKA_TOPIC_RESULTS     = os.environ.get('KAFKA_TOPIC_RESULTS', 'detection-results')
KAFKA_GROUP_ID          = os.environ.get('KAFKA_GROUP_ID', 'storage-group')
MONGODB_URI             = os.environ.get('MONGODB_URI', 'mongodb://admin:password123@localhost:27017/')
MONGODB_DB              = os.environ.get('MONGODB_DB', 'people_counting')
MAX_MSG_SIZE            = 15 * 1024 * 1024

# ── Stats ─────────────────────────────────────────────────────────────────────
stats = {
    'records_saved'  : 0,
    'records_failed' : 0,
    'started_at'     : datetime.utcnow().isoformat(),
}

# ── MongoDB ───────────────────────────────────────────────────────────────────
def make_mongo():
    for attempt in range(15):
        try:
            client = MongoClient(MONGODB_URI, serverSelectionTimeoutMS=5000)
            client.admin.command('ping')
            db = client[MONGODB_DB]
            logger.info("✅ MongoDB connected: %s / %s", MONGODB_URI, MONGODB_DB)
            return db
        except Exception as e:
            logger.warning("MongoDB attempt %d/15: %s", attempt + 1, e)
            time.sleep(5)
    raise RuntimeError("Cannot connect to MongoDB")


_db = None

def get_db():
    global _db
    if _db is None:
        _db = make_mongo()
    return _db


# ── Kafka consumer ────────────────────────────────────────────────────────────
def make_consumer():
    for attempt in range(15):
        try:
            c = KafkaConsumer(
                KAFKA_TOPIC_RESULTS,
                bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
                group_id=KAFKA_GROUP_ID,
                auto_offset_reset='latest',
                enable_auto_commit=True,
                value_deserializer=lambda v: json.loads(v.decode('utf-8')),
                max_partition_fetch_bytes=MAX_MSG_SIZE,
                fetch_max_bytes=MAX_MSG_SIZE,
            )
            logger.info("✅ Consumer subscribed to '%s'", KAFKA_TOPIC_RESULTS)
            return c
        except Exception as e:
            logger.warning("Consumer attempt %d/15: %s", attempt + 1, e)
            time.sleep(5)
    raise RuntimeError("Cannot create Kafka consumer")


_running = False


def storage_loop():
    global _running
    consumer = make_consumer()
    db       = get_db()
    _running = True
    logger.info("🚀 Storage loop started")

    for msg in consumer:
        if not _running:
            break
        try:
            doc = msg.value

            # Drop large base64 field before persisting (optional – saves disk)
            doc_to_save = {k: v for k, v in doc.items() if k != 'annotated_frame'}
            doc_to_save['saved_at'] = datetime.utcnow().isoformat()

            db['detection_results'].insert_one(doc_to_save)
            stats['records_saved'] += 1

            logger.info(
                "💾 Saved frame_id=%s camera=%s people=%d",
                doc.get('frame_id'), doc.get('camera_id'), doc.get('people_count', 0)
            )

            # ── Per-minute aggregation ─────────────────────────────────────
            minute_bucket = doc.get('timestamp_done', '')[:16]  # "YYYY-MM-DDTHH:MM"
            db['minute_stats'].update_one(
                {'_id': f"{doc.get('camera_id')}|{minute_bucket}"},
                {'$inc': {'frame_count': 1,
                          'total_people': doc.get('people_count', 0)},
                 '$set': {'camera_id': doc.get('camera_id'),
                          'minute'   : minute_bucket}},
                upsert=True,
            )

        except (PyMongoError, KeyError, ValueError) as exc:
            stats['records_failed'] += 1
            logger.error("❌ Storage error: %s", exc, exc_info=True)


# ── Background thread ─────────────────────────────────────────────────────────
def start_background():
    t = threading.Thread(target=storage_loop, daemon=True, name="storage-loop")
    t.start()
    logger.info("🔄 Background storage thread started")


# ── REST API ──────────────────────────────────────────────────────────────────
@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'service': 'storage-server',
                    'running': _running, **stats})


@app.route('/results', methods=['GET'])
def get_results():
    """
    GET /results?camera_id=CAM-001&limit=20&page=1
    Returns recent detection results.
    """
    camera_id = request.args.get('camera_id')
    limit     = min(int(request.args.get('limit', 20)), 100)
    page      = max(int(request.args.get('page', 1)), 1)
    skip      = (page - 1) * limit

    query = {}
    if camera_id:
        query['camera_id'] = camera_id

    db   = get_db()
    docs = list(
        db['detection_results']
        .find(query, {'_id': 0, 'annotated_frame': 0})
        .sort('timestamp_done', DESCENDING)
        .skip(skip)
        .limit(limit)
    )
    total = db['detection_results'].count_documents(query)

    return jsonify({
        'total'  : total,
        'page'   : page,
        'limit'  : limit,
        'results': docs,
    })


@app.route('/results/<frame_id>', methods=['GET'])
def get_result(frame_id):
    db  = get_db()
    doc = db['detection_results'].find_one(
        {'frame_id': frame_id}, {'_id': 0}
    )
    if not doc:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(doc)


@app.route('/summary', methods=['GET'])
def summary():
    """Aggregated count per camera."""
    db = get_db()
    pipeline = [
        {'$group': {
            '_id'          : '$camera_id',
            'total_frames' : {'$sum': 1},
            'total_people' : {'$sum': '$people_count'},
            'avg_people'   : {'$avg': '$people_count'},
            'max_people'   : {'$max': '$people_count'},
            'last_seen'    : {'$max': '$timestamp_done'},
        }},
        {'$sort': {'total_frames': -1}},
    ]
    rows = list(db['detection_results'].aggregate(pipeline))
    for r in rows:
        r['camera_id']   = r.pop('_id')
        r['avg_people']  = round(r['avg_people'], 2)

    return jsonify({'cameras': rows, 'total_cameras': len(rows)})


@app.route('/timeline', methods=['GET'])
def timeline():
    """
    GET /timeline?camera_id=CAM-001
    Per-minute people count for trend charts.
    """
    camera_id = request.args.get('camera_id')
    db        = get_db()
    query     = {}
    if camera_id:
        query['camera_id'] = camera_id

    rows = list(
        db['minute_stats']
        .find(query, {'_id': 0})
        .sort('minute', DESCENDING)
        .limit(60)
    )
    return jsonify({'timeline': list(reversed(rows))})


@app.route('/stats', methods=['GET'])
def get_stats():
    return jsonify({'service': 'storage-server', **stats})


@app.route('/cameras', methods=['GET'])
def list_cameras():
    db   = get_db()
    cams = db['detection_results'].distinct('camera_id')
    return jsonify({'cameras': cams})


# ── Entry ─────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    start_background()
    app.run(host='0.0.0.0', port=5003, debug=False)
