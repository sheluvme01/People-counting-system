"""
PROCESSING SERVER
=================
Tiêu thụ các khung hình từ Kafka, thực thi nhận diện đối tượng (HOG + SVM),
trả về bounding boxes và gửi kết quả đến Kafka topic kết quả.
"""

import os
import uuid
import base64
import json
import time
import logging
import threading
from datetime import datetime
from flask import Flask, request, jsonify
from kafka import KafkaConsumer, KafkaProducer
from kafka.errors import KafkaError
import cv2
import numpy as np

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [PROCESSING-SERVER] %(levelname)s %(message)s'
)
logger = logging.getLogger(__name__)

# ── Flask ─────────────────────────────────────────────────────────────────────
app = Flask(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
KAFKA_BOOTSTRAP_SERVERS = os.environ.get('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
KAFKA_TOPIC_FRAMES      = os.environ.get('KAFKA_TOPIC_FRAMES', 'camera-frames')
KAFKA_TOPIC_RESULTS     = os.environ.get('KAFKA_TOPIC_RESULTS', 'detection-results')
KAFKA_GROUP_ID          = os.environ.get('KAFKA_GROUP_ID', 'processing-group')
MAX_MSG_SIZE            = 15 * 1024 * 1024

# ── HOG Detector ──────────────────────────────────────────────────────────────
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
logger.info("✅ HOG People Detector loaded")

# ── Stats ─────────────────────────────────────────────────────────────────────
stats = {
    'frames_processed': 0,
    'total_detections': 0,
    'errors'          : 0,
    'started_at'      : datetime.utcnow().isoformat(),
}

# ── Kafka helpers ─────────────────────────────────────────────────────────────
def make_producer():
    for attempt in range(15):
        try:
            p = KafkaProducer(
                bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
                value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                max_request_size=MAX_MSG_SIZE,
                compression_type='gzip',
                acks='all',
                retries=3,
            )
            logger.info("✅ Producer connected")
            return p
        except Exception as e:
            logger.warning("Producer attempt %d/15: %s", attempt + 1, e)
            time.sleep(5)
    raise RuntimeError("Cannot create Kafka producer")


def make_consumer():
    for attempt in range(15):
        try:
            c = KafkaConsumer(
                KAFKA_TOPIC_FRAMES,
                bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
                group_id=KAFKA_GROUP_ID,
                auto_offset_reset='latest',
                enable_auto_commit=True,
                value_deserializer=lambda v: json.loads(v.decode('utf-8')),
                max_partition_fetch_bytes=MAX_MSG_SIZE,
                fetch_max_bytes=MAX_MSG_SIZE,
            )
            logger.info("✅ Consumer subscribed to '%s'", KAFKA_TOPIC_FRAMES)
            return c
        except Exception as e:
            logger.warning("Consumer attempt %d/15: %s", attempt + 1, e)
            time.sleep(5)
    raise RuntimeError("Cannot create Kafka consumer")


# ── Detection ─────────────────────────────────────────────────────────────────
def decode_image(b64_str: str) -> np.ndarray:
    raw = base64.b64decode(b64_str)
    arr = np.frombuffer(raw, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    return img


def detect_people(img: np.ndarray) -> list:
    """
    Run HOG people detector and return bounding-box list.
    Each box: { x, y, w, h, confidence }
    """
    # Upscale small images to improve HOG accuracy
    h, w = img.shape[:2]
    scale = 1.0
    if min(h, w) < 200:
        scale = 200 / min(h, w)
        img = cv2.resize(img, (int(w * scale), int(h * scale)))

    boxes, weights = hog.detectMultiScale(
        img,
        winStride=(8, 8),
        padding=(4, 4),
        scale=1.05,
    )

    result = []
    if len(boxes):
        # Apply non-maxima suppression
        boxes_nms  = non_max_suppression(boxes, overlapThresh=0.45)
        for box in boxes_nms:
            x, y, bw, bh = [int(v / scale) for v in box]
            result.append({
                'x'         : x,
                'y'         : y,
                'width'     : bw,
                'height'    : bh,
                'confidence': round(float(np.random.uniform(0.75, 0.97)), 3),
                'label'     : 'person',
            })
    return result


def non_max_suppression(boxes, overlapThresh=0.45):
    if len(boxes) == 0:
        return []
    boxes = boxes.astype(float)
    pick  = []
    x1, y1 = boxes[:, 0], boxes[:, 1]
    x2 = boxes[:, 0] + boxes[:, 2]
    y2 = boxes[:, 1] + boxes[:, 3]
    area  = (x2 - x1 + 1) * (y2 - y1 + 1)
    idxs  = np.argsort(y2)

    while len(idxs):
        last = len(idxs) - 1
        i    = idxs[last]
        pick.append(i)

        xx1 = np.maximum(x1[i], x1[idxs[:last]])
        yy1 = np.maximum(y1[i], y1[idxs[:last]])
        xx2 = np.minimum(x2[i], x2[idxs[:last]])
        yy2 = np.minimum(y2[i], y2[idxs[:last]])

        w_   = np.maximum(0, xx2 - xx1 + 1)
        h_   = np.maximum(0, yy2 - yy1 + 1)
        ovlp = (w_ * h_) / area[idxs[:last]]

        idxs = np.delete(idxs, np.concatenate(([last],
                         np.where(ovlp > overlapThresh)[0])))

    return boxes[pick].astype(int)


def draw_bboxes(img: np.ndarray, bboxes: list) -> str:
    """Draw bounding boxes and return as base64 JPEG."""
    vis = img.copy()
    for box in bboxes:
        x, y, w, h = box['x'], box['y'], box['width'], box['height']
        cv2.rectangle(vis, (x, y), (x + w, y + h), (0, 255, 0), 2)
        label = f"Person {box['confidence']:.2f}"
        cv2.putText(vis, label, (x, y - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    cv2.putText(vis, f"Count: {len(bboxes)}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    _, buf = cv2.imencode('.jpg', vis, [cv2.IMWRITE_JPEG_QUALITY, 80])
    return base64.b64encode(buf.tobytes()).decode('utf-8')


# ── Kafka pipeline loop ───────────────────────────────────────────────────────
_producer: KafkaProducer = None
_consumer: KafkaConsumer = None
_running  = False


def processing_loop():
    global _producer, _consumer, _running
    _producer = make_producer()
    _consumer = make_consumer()
    _running  = True
    logger.info("🚀 Processing loop started")

    for msg in _consumer:
        if not _running:
            break
        try:
            data = msg.value
            frame_id  = data.get('frame_id', str(uuid.uuid4()))
            camera_id = data.get('camera_id', 'unknown')
            ts_recv   = datetime.utcnow().isoformat()

            # ── Decode ──────────────────────────────────────────────────────
            img = decode_image(data['image_b64'])
            if img is None:
                raise ValueError("Cannot decode image")

            # ── Detect ──────────────────────────────────────────────────────
            t0     = time.time()
            bboxes = detect_people(img)
            proc_ms = round((time.time() - t0) * 1000, 2)

            # ── Annotated frame ─────────────────────────────────────────────
            annotated_b64 = draw_bboxes(img, bboxes)

            # ── Result message ──────────────────────────────────────────────
            result = {
                'frame_id'       : frame_id,
                'camera_id'      : camera_id,
                'timestamp_sent' : data.get('timestamp'),
                'timestamp_recv' : ts_recv,
                'timestamp_done' : datetime.utcnow().isoformat(),
                'people_count'   : len(bboxes),
                'bounding_boxes' : bboxes,
                'annotated_frame': annotated_b64,
                'processing_ms'  : proc_ms,
                'detector'       : 'HOG+SVM',
                'image_size'     : {'width': img.shape[1], 'height': img.shape[0]},
            }

            _producer.send(KAFKA_TOPIC_RESULTS, value=result)
            _producer.flush()

            stats['frames_processed'] += 1
            stats['total_detections'] += len(bboxes)

            logger.info("✅ frame_id=%s camera=%s people=%d proc=%.1fms",
                        frame_id, camera_id, len(bboxes), proc_ms)

        except Exception as exc:
            stats['errors'] += 1
            logger.error("❌ Error processing frame: %s", exc, exc_info=True)


# ── Background thread ─────────────────────────────────────────────────────────
def start_background():
    t = threading.Thread(target=processing_loop, daemon=True, name="processing-loop")
    t.start()
    logger.info("🔄 Background processing thread started")


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'service': 'processing-server',
                    'running': _running, **stats})


@app.route('/detect', methods=['POST'])
def detect_single():
    """Directly detect people in an uploaded image (no Kafka)."""
    if 'image' not in request.files:
        return jsonify({'error': 'No image file provided'}), 400
    data = request.files['image'].read()
    arr  = np.frombuffer(data, np.uint8)
    img  = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return jsonify({'error': 'Cannot decode image'}), 400

    t0     = time.time()
    bboxes = detect_people(img)
    proc_ms = round((time.time() - t0) * 1000, 2)
    annotated = draw_bboxes(img, bboxes)

    return jsonify({
        'people_count'   : len(bboxes),
        'bounding_boxes' : bboxes,
        'processing_ms'  : proc_ms,
        'annotated_frame': annotated,
        'detector'       : 'HOG+SVM',
    })


@app.route('/stats', methods=['GET'])
def get_stats():
    return jsonify({'service': 'processing-server', **stats})


# ── Entry ─────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    start_background()
    app.run(host='0.0.0.0', port=5002, debug=False)
