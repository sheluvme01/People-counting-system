from app import app, start_background

# Start Kafka consumer thread once (before gunicorn forks workers)
start_background()

application = app
